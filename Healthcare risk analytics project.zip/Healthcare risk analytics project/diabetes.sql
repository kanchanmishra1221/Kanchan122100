create database healthcare_risk_analytics;
CREATE TABLE patients (
    patient_id INT PRIMARY KEY,
    age INT CHECK (age BETWEEN 18 AND 90),
    gender VARCHAR(10) CHECK (gender IN ('Male','Female')),
    city VARCHAR(50),
    state VARCHAR(50),
    insurance_type VARCHAR(30),
    family_history_diabetes VARCHAR(5),
    family_history_heart VARCHAR(5)
);
CREATE TABLE risk_factors (
    risk_id INT PRIMARY KEY,
    patient_id INT REFERENCES patients(patient_id),
    bmi NUMERIC(4,1) CHECK (bmi > 10 AND bmi < 60),
    smoker VARCHAR(10),
    alcohol_use VARCHAR(20),
    exercise_freq VARCHAR(30),
    avg_sleep_hours NUMERIC(3,1),
    stress_level VARCHAR(20)
);
CREATE TABLE checkups (
    checkup_id INT PRIMARY KEY,
    patient_id INT REFERENCES patients(patient_id),
    checkup_date DATE,
    systolic_bp INT CHECK (systolic_bp BETWEEN 80 AND 250),
    diastolic_bp INT CHECK (diastolic_bp BETWEEN 40 AND 150),
    blood_sugar NUMERIC(5,1),
    hba1c NUMERIC(3,1),
    ldl_cholesterol INT,
    hdl_cholesterol INT
);
CREATE TABLE diagnoses (
    diag_id INT PRIMARY KEY,
    patient_id INT REFERENCES patients(patient_id),
    checkup_id INT REFERENCES checkups(checkup_id),
    diagnosis_date DATE,
    icd10_code VARCHAR(10),
    diagnosis_name VARCHAR(100),
    severity_level VARCHAR(20)
);
CREATE INDEX idx_checkups_patient_id
ON checkups(patient_id);
CREATE INDEX idx_checkups_date
ON checkups(checkup_date);
CREATE INDEX idx_diagnoses_icd10
ON diagnoses(icd10_code);
CREATE INDEX idx_risk_patient
ON risk_factors(patient_id);
COPY patients
FROM 'C:\Patients.csv'
DELIMITER ','
CSV HEADER;

COPY risk_factors
FROM 'C:\risk_factors.csv'
DELIMITER ','
CSV HEADER;
copy checkups
FROM 'C:\checkups.csv'
DELIMITER ','
CSV HEADER;
copy diagnoses
FROM 'C:\diagnoses.csv'
DELIMITER ','
CSV HEADER;
UPDATE risk_factors
SET smoker = 'Yes'
WHERE smoker = 'yes';
select * from patients;
SELECT COUNT(DISTINCT patient_id)
FROM diagnoses
WHERE icd10_code = 'E11.9';
select * from checkups;
select round (avg(hba1c),1)from checkups;
select * from risk_factors;
select round(avg(bmi),1),smoker from risk_factors
group by smoker;

select p.city, count(*)as diabetes_cases from patients p
JOIN diagnoses d
ON p.patient_id = d.patient_id
WHERE d.icd10_code = 'E11.9'
GROUP BY p.city
ORDER BY diabetes_cases DESC;
SELECT COUNT(*)
FROM diagnoses;
SELECT
    p.patient_id,
    p.age,
    r.bmi,
    c.hba1c
FROM patients p
JOIN risk_factors r
ON p.patient_id = r.patient_id
JOIN checkups c
ON p.patient_id = c.patient_id;
--high risk patients?
WITH high_risk AS (

    SELECT
        patient_id,
        bmi,
        smoker
    FROM risk_factors
    WHERE bmi > 30
      AND smoker IN ('Yes')
)
SELECT *
FROM high_risk;
-- worsening diabetes trend?
SELECT
    patient_id,
    checkup_date,
    hba1c,

    LAG(hba1c) OVER (
        PARTITION BY patient_id
        ORDER BY checkup_date
    ) AS previous_hba1c

FROM checkups;

SELECT
    patient_id,
    hba1c,

    RANK() OVER (
        ORDER BY hba1c DESC
    ) AS risk_rank

FROM checkups;
