Create database healthcare_analysis;
CREATE TABLE cause_of_deaths (
    country VARCHAR(100),
    code VARCHAR(10),
    death_year INT,
    disease VARCHAR(100),
    death_count BIGINT
);

--most dangerous disease in each country 
 WITH disease_rank AS (
    SELECT
        country,
        disease,
        SUM(death_count) AS total_deaths,
        RANK() OVER (
            PARTITION BY country
            ORDER BY SUM(death_count) DESC
        ) AS rank_num
    FROM cause_of_deaths
    GROUP BY country, disease
)
SELECT
    country,
    disease,
    total_deaths
FROM disease_rank
WHERE rank_num = 1
ORDER BY total_deaths DESC;
-- Disease with highest mortality?
SELECT disease,
       SUM(death_count) AS total_deaths
FROM cause_of_deaths
GROUP BY disease
ORDER BY total_deaths DESC;
--top 10 countries with highest deaths?
SELECT country,
       SUM(death_count) AS total_deaths
FROM cause_of_deaths
GROUP BY country
ORDER BY total_deaths DESC
LIMIT 10;
-- Disease trend over time
SELECT death_year,
       SUM(death_count) AS total_deaths
FROM cause_of_deaths
GROUP BY death_year
ORDER by death_year;
--Highest growing disease.....
Select disease, sum(death_count) as total_deaths
from cause_of_deaths
group by disease
order by total_deaths desc;



