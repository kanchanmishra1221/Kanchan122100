 CREATE TABLE cause_of_deaths (
    country VARCHAR(100),
    code VARCHAR(10),
    death_year INT,
    disease VARCHAR(100),
    death_count BIGINT
);
select * from cause_of_deaths;
copy cause_of_deaths
from 'C:\cause_of_death\cause_of death_raw_cleaned.csv'
DELIMITER ',' 
CSV HEADER;